package com.example.yourvehicle;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FragNameEdit extends Fragment {
    private Button backButton, saveButton;
    private VehicleDatabaseHelper dbhelper; // Database helper object
    String fbEmail = null,other=null;
    EditText editText;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.frag_name_edit, container, false);

        initializeButtons(view);
        setupBackButton();
        setupSaveButton();
        editText = view.findViewById(R.id.editSeciton);

        // Initialize the database helper
        dbhelper = new VehicleDatabaseHelper(getContext());

        Bundle bundle = getArguments();
        if (bundle != null) {
            fbEmail = bundle.getString("fbEmail");
            other = bundle.getString("other");
            assert other != null;
            if (other.equals("EditUserName")) {
                editText.setHint("Enter New User Name");
            }
            if (other.equals("EditUserEmail")) {
                editText.setHint("Enter New Email");
            }
            if (other.equals("EditUserPhone")) {
                editText.setHint("Enter New Phone Number");
            }
            if (other.equals("EditUserAddress")) {
                editText.setHint("Enter New Address");
            }
            if (other.equals("EditUserPassword")) {
                editText.setHint("Enter New Password");
            }
        }

        return view;
    }

    private void initializeButtons(View view) {
        backButton = view.findViewById(R.id.login_button2);
        saveButton = view.findViewById(R.id.login_button3);
    }

    private void setupBackButton() {
        backButton.setOnClickListener(v -> navigateTo(UserSection.class));
    }

    private void setupSaveButton() {
        saveButton.setOnClickListener(v -> {
            String newUserName = editText.getText().toString().trim();
            if (newUserName.isEmpty()) {
                Toast.makeText(getContext(), "User name cannot be empty", Toast.LENGTH_SHORT).show();
                return;
            }
            if (other.equals("EditUserName")) {
            String msg = dbhelper.editUserName(fbEmail, newUserName);
            navigateToUserSectionWithMessage(msg);
            }
            if (other.equals("EditUserEmail")) {
                String msg = dbhelper.editEmail(fbEmail, newUserName);
                navigateToUserSectionWithMessage(msg);
            }
            if (other.equals("EditUserPhone")) {
                String msg = dbhelper.editPhone(fbEmail, newUserName);
                navigateToUserSectionWithMessage(msg);
            }
            if (other.equals("EditUserAddress")) {
                String msg = dbhelper.editAddress(fbEmail, newUserName);
                navigateToUserSectionWithMessage(msg);
            }

        });
    }

    private void navigateTo(Class<?> cls) {
        Intent intent = new Intent(getActivity(), cls);
        startActivity(intent);
    }

    private void navigateToUserSectionWithMessage(String message) {
        Intent intent = new Intent(getActivity(), UserSection.class);
        intent.putExtra("msg", message);
        intent.putExtra("fbEmail", fbEmail);
        startActivity(intent);
    }
}
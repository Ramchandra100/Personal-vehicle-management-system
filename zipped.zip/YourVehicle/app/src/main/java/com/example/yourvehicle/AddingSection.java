package com.example.yourvehicle;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class AddingSection extends AppCompatActivity {

    private BottomNavigationView bottomNavigationView;
    String fbEmail=null;
    VehicleDatabaseHelper vehicleDatabaseHelper=new VehicleDatabaseHelper(this);
    Vehicle vehicleInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.adding_section);




        setupWindowInsets();
        handleIntentExtras();
        setupTextAndButtons();
        setupBottomNavigation();

        Intent intent = getIntent();
        fbEmail=intent.getStringExtra("fbEmail");
        if (getIntent().hasExtra("vehicle")) {
            vehicleInfo = vehicleDatabaseHelper.getVehicleOject(fbEmail);

            replaceFragmentWithFbEmail(new AddSectionInputOne(), "update", fbEmail,"CAR");

        }


    }

    private void setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void setupTextAndButtons() {

        findViewById(R.id.carBtn).setOnClickListener(v -> {

            replaceFragmentWithFbEmail(new AddSectionInputOne(), "Let's Gather Some Information",fbEmail,"CAR");
        });
        findViewById(R.id.bikeBtn).setOnClickListener(v -> {
            replaceFragmentWithFbEmail(new AddSectionInputOne(),"Let's Gather Some Information", fbEmail,"BIKE");
        });
        findViewById(R.id.truckBtn).setOnClickListener(v -> {
            replaceFragmentWithFbEmail(new AddSectionInputOne(),"Let's Gather Some Information", fbEmail,"TRUCK");
        });
    }

    private void replaceFragmentWithFbEmail(Fragment fragment,String setString, String fbEmail,String Vehicle_type) {
        TextView t = findViewById(R.id.disType);
        t.setText(setString);
        t.setTextSize(20);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        // Pass fbEmail to the fragment
        Bundle bundle = new Bundle();
        bundle.putString("fbEmail", fbEmail);
        bundle.putString("type",Vehicle_type);
        if(setString.equals("update")){
            bundle.putSerializable("vehicle", vehicleInfo);
            bundle.putString("update","update");
            t.setText("Here Update Goes");
        }
        fragment.setArguments(bundle);

        fragmentTransaction.replace(R.id.frameLayout3, fragment);
        fragmentTransaction.commit();
    }

    private void setupBottomNavigation() {
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.navigation_home) {
                navigateTo(Dashboard.class);
                return true;
            } else if (item.getItemId() == R.id.navigation_switch) {
                Toast.makeText(this, "Navigate to the home and to view the updated changes", Toast.LENGTH_SHORT).show();
                return true;
            } else if (item.getItemId() == R.id.navigation_add) {
                navigateTo(AddingSection.class);
                return true;
            }
            return false;
        });
    }

    private void navigateTo(Class<?> cls) {
        Intent intent = new Intent(this, cls);
        intent.putExtra("fbEmail", fbEmail);
        startActivity(intent);
        finish();
    }

    private void handleIntentExtras() {
        Intent intent = getIntent();
        if (intent!=null && intent.getStringExtra("fbEmail")!=null){
            fbEmail=intent.getStringExtra("fbEmail");

        }
        if (intent != null && intent.getStringExtra("msg") != null) {
            Toast.makeText(this, intent.getStringExtra("msg"), Toast.LENGTH_SHORT).show();
        }
    }
}
package com.example.yourvehicle;

import java.io.Serializable;

public class Vehicle implements Serializable {
    private int id;
    private String modelNo;
    private String vehicleNo;
    private String color;
    private String kms;
    private String fuelType;
    private String licenceNo;
    private String issueDate;
    private String expiryDate;
    private String address;
    private String pucIssueDate;
    private String pucExpiryDate;
    private String coLevel;
    private String status;
    private String lastServiceDate;
    private String serviceAmount;
    private String serviceType;
    private String vehicleType;
    private String insuranceNo;
    private String insuranceProvider;
    private String insuranceStartDate;
    private String insuranceEndDate;
    private String insuranceCoverage;
    private String userName; // Added
    private String email;    // Added
    private String password; // Added
    private String totalFine;
    private String fineDate;
    private String phone;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getModelNo() {
        return modelNo;
    }

    public void setModelNo(String modelNo) {
        this.modelNo = modelNo;
    }

    public String getvehicleNo() {
        return vehicleNo;
    }

    public void setvehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getKms() {
        return kms;
    }

    public void setKms(String kms) {
        this.kms = kms;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public String getLicenceNo() {
        return licenceNo;
    }

    public void setLicenceNo(String licenceNo) {
        this.licenceNo = licenceNo;
    }

    public String getIssueDate() {
        return issueDate;
    }

    public void setIssueDate(String issueDate) {
        this.issueDate = issueDate;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPucIssueDate() {
        return pucIssueDate;
    }

    public void setPucIssueDate(String pucIssueDate) {
        this.pucIssueDate = pucIssueDate;
    }

    public String getPucExpiryDate() {
        return pucExpiryDate;
    }

    public void setPucExpiryDate(String pucExpiryDate) {
        this.pucExpiryDate = pucExpiryDate;
    }

    public String getCoLevel() {
        return coLevel;
    }

    public void setCoLevel(String coLevel) {
        this.coLevel = coLevel;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getLastServiceDate() {
        return lastServiceDate;
    }

    public void setLastServiceDate(String lastServiceDate) {
        this.lastServiceDate = lastServiceDate;
    }

    public String getServiceAmount() {
        return serviceAmount;
    }

    public void setServiceAmount(String serviceAmount) {
        this.serviceAmount = serviceAmount;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getInsuranceNo() {
        return insuranceNo;
    }

    public void setInsuranceNo(String insuranceNo) {
        this.insuranceNo = insuranceNo;
    }

    public String getInsuranceProvider() {
        return insuranceProvider;
    }

    public void setInsuranceProvider(String insuranceProvider) {
        this.insuranceProvider = insuranceProvider;
    }

    public String getInsuranceStartDate() {
        return insuranceStartDate;
    }

    public void setInsuranceStartDate(String insuranceStartDate) {
        this.insuranceStartDate = insuranceStartDate;
    }

    public String getInsuranceEndDate() {
        return insuranceEndDate;
    }

    public void setInsuranceEndDate(String insuranceEndDate) {
        this.insuranceEndDate = insuranceEndDate;
    }

    public String getInsuranceCoverage() {
        return insuranceCoverage;
    }

    public void setInsuranceCoverage(String insuranceCoverage) {
        this.insuranceCoverage = insuranceCoverage;
    }

    // Added getters and setters for new fields
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setTotalFine(String totalFineText) {
        this.totalFine = totalFineText;
    }

    public void setFineDate(String fineDateText) {
        this.fineDate = fineDateText;
    }

    public String getFineDate() {
        return fineDate;
    }

    public String getTotalFine() {
        return totalFine;
    }

    public void setPhone(String string) {
        this.phone = string;
    }

    public String getPhone() {
        return phone;
    }
}
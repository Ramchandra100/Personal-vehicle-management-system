package com.example.yourvehicle;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.Calendar;
import java.util.Objects;

public class AddingSectionInputTwo extends Fragment {
    private EditText licenceNo, address, coLevel, status, phoneNumber;
    private Vehicle vehicle;
    private TextView issueDate, expiryDate,pucIssueDate, pucExpiryDate;
    String fbEmail,check="no";
    View view;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.adding_section_input_two, container, false);

        licenceNo = view.findViewById(R.id.licenceNo);
        issueDate = view.findViewById(R.id.licenceIssueDate);
        expiryDate = view.findViewById(R.id.expiryDate);
        address = view.findViewById(R.id.Address);
        pucIssueDate = view.findViewById(R.id.pucIssueDate);
        pucExpiryDate = view.findViewById(R.id.pucExpiryDate);
        coLevel = view.findViewById(R.id.COLevel);
        status = view.findViewById(R.id.status);
        phoneNumber = view.findViewById(R.id.PhoneNumber);


        pucIssueDate.setOnClickListener(v -> showDatePickerDialog(pucIssueDate));
        pucExpiryDate.setOnClickListener(v -> showDatePickerDialog(pucExpiryDate));
        issueDate.setOnClickListener(v -> showDatePickerDialog(issueDate));
        expiryDate.setOnClickListener(v -> showDatePickerDialog(expiryDate));

        Bundle arguments = getArguments();
        assert arguments != null;
        fbEmail = arguments.getString("fbEmail");
        if (arguments.getString("update") != null && Objects.equals(arguments.getString("update"), "update")) {
            vehicle = (Vehicle) arguments.getSerializable("vehicle");
            check=arguments.getString("update");
            Toast.makeText(getContext(), "Helo: " + vehicle.getModelNo(), Toast.LENGTH_SHORT).show();
            bindEditTexts(licenceNo,vehicle.getLicenceNo());
            issueDate.setText(vehicle.getIssueDate());
            expiryDate.setText(vehicle.getExpiryDate());
            bindEditTexts(address,vehicle.getAddress());
            pucIssueDate.setText(vehicle.getPucIssueDate());
            pucExpiryDate.setText(vehicle.getPucExpiryDate());
            bindEditTexts(coLevel,vehicle.getCoLevel());
            bindEditTexts(status,vehicle.getStatus());
            bindEditTexts(phoneNumber,vehicle.getPhone());

        }else {
            vehicle = (Vehicle) arguments.getSerializable("vehicle");
        }

        Button nextButton = view.findViewById(R.id.login_button7);
        nextButton.setOnClickListener(v -> {
            if (validateInput()) {
                vehicle.setLicenceNo(licenceNo.getText().toString().trim());
                vehicle.setIssueDate(issueDate.getText().toString().trim());
                vehicle.setExpiryDate(expiryDate.getText().toString().trim());
                vehicle.setAddress(address.getText().toString().trim());
                vehicle.setPucIssueDate(pucIssueDate.getText().toString().trim());
                vehicle.setPucExpiryDate(pucExpiryDate.getText().toString().trim());
                vehicle.setCoLevel(coLevel.getText().toString().trim());
                vehicle.setStatus(status.getText().toString().trim());
                vehicle.setPhone(phoneNumber.getText().toString().trim());

                // Pass the vehicle object to the next fragment
                Bundle newBundle = new Bundle();
                Bundle bundleRetrive = getArguments();
                if (bundleRetrive != null) {
                    String fbEmail = bundleRetrive.getString("fbEmail");
                    newBundle.putString("fbEmail", fbEmail);
                }
                if(check.equals("update")){
                    newBundle.putString("update","update");
                }
                    newBundle.putSerializable("vehicle", vehicle);

                AddingSectionInputThree fragment = new AddingSectionInputThree();
                fragment.setArguments(newBundle);

                getParentFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainer, fragment)
                        .addToBackStack(null)
                        .commit();
            }
        });

        Button backButton = view.findViewById(R.id.login_button6);
        backButton.setOnClickListener(view1 -> {

            Bundle newBundle = new Bundle();
            Bundle bundleRetrive = getArguments();
            if (bundleRetrive != null) {
                String fbEmail = bundleRetrive.getString("fbEmail");
                newBundle.putString("fbEmail", fbEmail);
            }
            if(check.equals("update")){
                newBundle.putString("update","update");
            }
            newBundle.putSerializable("vehicle", vehicle);
            AddSectionInputOne fragment = new AddSectionInputOne();
            fragment.setArguments(newBundle);
            getParentFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainer, fragment)
                    .addToBackStack(null)
                    .commit();
        });

        return view;
    }

    private void bindEditTexts(EditText ed, String text) {
        ed.setText(text);
    }

    private void showDatePickerDialog(TextView textView) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                requireContext(),
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        // Handle the selected date
                        textView.setText(dayOfMonth + "-" + (month + 1) + "-" + year);
                    }
                },
                year,
                month,
                day
        );

        datePickerDialog.show();
    }

    private boolean validateInput() {
        if (licenceNo.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Licence No cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (issueDate.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Issue Date cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (expiryDate.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Expiry Date cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (address.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Address cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (pucIssueDate.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "PUC Issue Date cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (pucExpiryDate.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "PUC Expiry Date cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (coLevel.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "CO Level cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (status.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Status cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
package com.example.yourvehicle;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Dashboard extends AppCompatActivity {
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    private FusedLocationProviderClient fusedLocationClient;
    private String fbEmail;
    private TextView update;
    private VehicleDatabaseHelper vehicleDatabaseHelper;
    private  ImageView image_dash;
    Vehicle vehicleInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);

        setupWindowInsets();
        setupUserListeners();
        setupBottomNavigation();
        setupLocationButton();

        fbEmail = getIntent().getStringExtra("fbEmail");
        vehicleDatabaseHelper = new VehicleDatabaseHelper(this);

        setupVehicleInfo();

    }

    private void setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void setupUserListeners() {
        ImageView userSectionTab = findViewById(R.id.user_section_tab);
        userSectionTab.setOnClickListener(v -> {
            Intent intent = new Intent(Dashboard.this, UserSection.class);
            intent.putExtra("fbEmail", fbEmail);
            intent.putExtra("vehicleObj", vehicleInfo);
            startActivity(intent);
        });
        update = findViewById(R.id.update01);
        update.setOnClickListener(view -> {
            Intent intent=new Intent(Dashboard.this,AddingSection.class);
            intent.putExtra("fbEmail", fbEmail);
            intent.putExtra("vehicle", vehicleInfo);
            startActivity(intent);
        });
    }

    private void setupBottomNavigation() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.navigation_home) {
                navigateTo(Dashboard.class);
                return true;
            } else if (item.getItemId() == R.id.navigation_switch) {
                vehicleDatabaseHelper.shuffleRowsForEmail(fbEmail);
                navigateTo(Dashboard.class);
                return true;
            } else if (item.getItemId() == R.id.navigation_add) {
                navigateTo(AddingSection.class);
                return true;
            }
            return false;
        });
    }

    private void setupLocationButton() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        ImageView getCurrentLocationImage = findViewById(R.id.current_location_image);
        getCurrentLocationImage.setOnClickListener(v -> getLocation());
    }

    private void setupVehicleInfo() {
        vehicleInfo = vehicleDatabaseHelper.getVehicleOject(fbEmail);
        bindVehicleInfoToViews(vehicleInfo);
    }

    private void bindVehicleInfoToViews(Vehicle vehicleInfo) {
        bindTextViewById(R.id.modelNo, vehicleInfo.getModelNo());
        bindTextViewById(R.id.kms, vehicleInfo.getKms() + " Kms");
        bindTextViewById(R.id.textView8, "Name : " + vehicleInfo.getUserName());
        bindTextViewById(R.id.licenceNo, "Licence No : " + vehicleInfo.getLicenceNo());
        bindTextViewById(R.id.licenceExpiry, "Expiry Date : " + vehicleInfo.getExpiryDate());
        bindTextViewById(R.id.address, "Address : " + vehicleInfo.getAddress());
        bindTextViewById(R.id.textView5, "Last Service Date : " + vehicleInfo.getLastServiceDate());
        bindTextViewById(R.id.textView9, "Next Service Date : " + vehicleInfo.getLastServiceDate());
        bindTextViewById(R.id.textView10, "Service Type : " + vehicleInfo.getServiceType());
        bindTextViewById(R.id.insuranceNo, "Insurance No : " + vehicleInfo.getInsuranceNo());
        bindTextViewById(R.id.insuranceProvider, "Insurance Provider : " + vehicleInfo.getInsuranceProvider());
        bindTextViewById(R.id.insuranceStartDate, "Insurance Start Date : " + vehicleInfo.getInsuranceStartDate());
        bindTextViewById(R.id.insuranceEndDate, "Insurance End Date : " + vehicleInfo.getInsuranceEndDate());
        bindTextViewById(R.id.insuranceCoverage, "Insurance Coverage : " + vehicleInfo.getInsuranceCoverage());
        bindTextViewById(R.id.issueDate, "PUC Issue Date : " + vehicleInfo.getPucIssueDate());
        bindTextViewById(R.id.expiryDate, "PUC Expiry Date : " + vehicleInfo.getPucExpiryDate());
        bindTextViewById(R.id.coLevel, "Co Level : " + vehicleInfo.getCoLevel());
        bindTextViewById(R.id.status, "Status : " + vehicleInfo.getStatus());
        bindTextViewById(R.id.fineDate, "Issue Date : " + vehicleInfo.getFineDate());
        bindTextViewById(R.id.usernameDown, vehicleDatabaseHelper.getUserByEmail(fbEmail));
        bindTextViewById(R.id.textView26, fbEmail);
        bindTextViewById(R.id.textView27, vehicleInfo.getAddress());
        bindTextViewById(R.id.vehicleNo, "Vehicle No : " + vehicleInfo.getvehicleNo());
        bindTextViewById(R.id.vehicleColor, "Color : " + vehicleInfo.getColor());
        bindTextViewById(R.id.vehicleFuelType, "Fuel Type : " + vehicleInfo.getFuelType());
        bindTextViewById(R.id.totalFine, "Total Fine : " + vehicleInfo.getTotalFine());
        bindTextViewById(R.id.userPhoneNumber, "Phone No : " + vehicleInfo.getPhone());


        if (!"Battery".equals(vehicleInfo.getFuelType())) {
            findViewById(R.id.card_battery_lock).setVisibility(View.GONE);
        } else {
            findViewById(R.id.overViewUp).setVisibility(View.GONE);
        }
        if("CAR".equals(vehicleInfo.getVehicleType())){
            image_dash = findViewById(R.id.dash_vehicle);
            image_dash.setImageResource(R.drawable.car_dash);
        }
        if("TRUCK".equals(vehicleInfo.getVehicleType())){
            image_dash = findViewById(R.id.dash_vehicle);
            image_dash.setImageResource(R.drawable.truck_dash);
        }
        if("BIKE".equals(vehicleInfo.getVehicleType())){
            image_dash = findViewById(R.id.dash_vehicle);
            image_dash.setImageResource(R.drawable.bike_dash);
        }
        if("BIKE".equals(vehicleInfo.getVehicleType()) && "Battery".equals(vehicleInfo.getFuelType())){
            image_dash = findViewById(R.id.dash_vehicle);
            image_dash.setImageResource(R.drawable.electric_bike_dash);
        }
    }

    private void bindTextViewById(int viewId, String text) {
        TextView textView = findViewById(viewId);
        textView.setText(text);
    }


    private void getLocation() {
        if (!hasLocationPermissions()) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
            return;
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, location -> {
                    if (location != null) {
                        openGoogleMaps(location.getLatitude(), location.getLongitude());
                    } else {
                        Toast.makeText(Dashboard.this, "Location not found", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private boolean hasLocationPermissions() {
        return ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @SuppressLint("QueryPermissionsNeeded")
    private void openGoogleMaps(double latitude, double longitude) {
        Uri gmmIntentUri = Uri.parse("geo:" + latitude + "," + longitude + "?z=16");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");

        if (mapIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(mapIntent);
        } else {
            Uri webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=" + latitude + "," + longitude);
            Intent webIntent = new Intent(Intent.ACTION_VIEW, webUri);
            startActivity(webIntent);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLocation();
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void navigateTo(Class<?> cls) {
        Intent intent = new Intent(this, cls);
        intent.putExtra("fbEmail", fbEmail);
        startActivity(intent);
    }
}
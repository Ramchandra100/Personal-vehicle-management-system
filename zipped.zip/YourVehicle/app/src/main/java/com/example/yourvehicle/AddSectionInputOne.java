package com.example.yourvehicle;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.Calendar;
import java.util.Objects;

public class AddSectionInputOne extends Fragment {
    private EditText modelNo, vehicleNo, color, kms, insuranceNo, insuranceProvider, insuranceCoverage;
    private Spinner fuelTypeSpinner;
    private Vehicle vehicle;
    private TextView insuranceStartDate, insuranceEndDate;
    private String fbEmail,check="no";
    View view;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.add_section_input_one, container, false);



        modelNo = view.findViewById(R.id.modelNo);
        vehicleNo = view.findViewById(R.id.vehicleNo);
        color = view.findViewById(R.id.color);
        kms = view.findViewById(R.id.kms);
        insuranceNo = view.findViewById(R.id.insuranceNo);
        insuranceProvider = view.findViewById(R.id.insuranceProvider);
        insuranceStartDate = view.findViewById(R.id.insuranceStartDate);
        insuranceEndDate = view.findViewById(R.id.insuranceEndDate);
        insuranceCoverage = view.findViewById(R.id.insuranceCoverage);

        fuelTypeSpinner = view.findViewById(R.id.fuelTypeSpinner);




        ArrayAdapter<String> fuelTypeAdapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, new String[]{"Choose Fuel Type :", "Petrol", "Battery", "CNG"});
        fuelTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fuelTypeSpinner.setAdapter(fuelTypeAdapter);
        fuelTypeSpinner.setSelection(0); // Set the default selection to the dummy entry

        // Retrieve the arguments
        Bundle arguments = getArguments();
        assert arguments != null;
        fbEmail = arguments.getString("fbEmail");
        if (arguments.getString("update") != null) {
            check = arguments.getString("update");
            vehicle = (Vehicle) arguments.getSerializable("vehicle");
            Toast.makeText(getContext(), "Helo: " + vehicle.getModelNo(), Toast.LENGTH_SHORT).show();
            bindEditTexts(modelNo,vehicle.getModelNo());
            bindEditTexts(vehicleNo,vehicle.getvehicleNo());
            bindEditTexts(color,vehicle.getColor());
            bindEditTexts(kms,vehicle.getKms());
            bindEditTexts(insuranceNo,vehicle.getInsuranceNo());
            bindEditTexts(insuranceProvider,vehicle.getInsuranceProvider());
            insuranceEndDate.setText(vehicle.getInsuranceEndDate());
            insuranceStartDate.setText(vehicle.getInsuranceStartDate());
            bindEditTexts(insuranceCoverage,vehicle.getInsuranceCoverage());
            if(vehicle.getFuelType().equals("Petrol")||vehicle.getFuelType().equals("Diesel")) {
                fuelTypeSpinner.setSelection(1);
            }
            if (vehicle.getFuelType().equals("Battery")) {
                fuelTypeSpinner.setSelection(2);
            }
            if (vehicle.getFuelType().equals("CNG")) {
                fuelTypeSpinner.setSelection(3);
            }
        }
if(!check.equals("update")){
    vehicle = new Vehicle();
}


        insuranceStartDate.setOnClickListener(view1 -> {
            showDatePickerDialog(insuranceStartDate);
        });
        insuranceEndDate.setOnClickListener(view1 -> {
            showDatePickerDialog(insuranceEndDate);
        });

        Button nextButton = view.findViewById(R.id.login_button7);
        nextButton.setOnClickListener(v -> {
            if (validateInput()) {
                vehicle.setModelNo(modelNo.getText().toString().trim());
                vehicle.setvehicleNo(vehicleNo.getText().toString().trim());
                vehicle.setColor(color.getText().toString().trim());
                vehicle.setKms(kms.getText().toString().trim());
                vehicle.setFuelType(fuelTypeSpinner.getSelectedItem().toString().trim());
                vehicle.setInsuranceNo(insuranceNo.getText().toString().trim());
                vehicle.setInsuranceProvider(insuranceProvider.getText().toString().trim());
                vehicle.setInsuranceStartDate(insuranceStartDate.getText().toString().trim());
                vehicle.setInsuranceEndDate(insuranceEndDate.getText().toString().trim());
                vehicle.setInsuranceCoverage(insuranceCoverage.getText().toString().trim());

                // Pass the vehicle object to the next fragment
                Bundle bundle = new Bundle();
                Bundle bundleRetrive = getArguments();

                if (bundleRetrive != null) {
                    String fbEmail = bundleRetrive.getString("fbEmail");
                    if(check.equals("update")) {
                        bundle.putString("update", "update");
                    }else{
                        String type = bundleRetrive.getString("type");
                        vehicle.setVehicleType(type);
                    }
                    bundle.putString("fbEmail", fbEmail);
                }
                bundle.putSerializable("vehicle", vehicle);
                AddingSectionInputTwo fragment = new AddingSectionInputTwo();
                fragment.setArguments(bundle);

                getParentFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainer, fragment)
                        .addToBackStack(null)
                        .commit();
            }
        });

        Button backButton = view.findViewById(R.id.login_button6);
        backButton.setOnClickListener(view1 -> {
            Intent intent = new Intent(getActivity(), AddingSection.class);
            startActivity(intent);
        });

        return view;
    }

    private void bindEditTexts(EditText ed, String text) {
        ed.setText(text);
    }

    private void showDatePickerDialog(TextView textView) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                requireContext(),
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        // Handle the selected date
                        textView.setText(dayOfMonth + "-" + (month + 1) + "-" + year);
                    }
                },
                year,
                month,
                day
        );

        datePickerDialog.show();
    }

    private boolean validateInput() {
        if (modelNo.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Model No cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (vehicleNo.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Vehicle No cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (color.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Color cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (kms.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "KMS cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (fuelTypeSpinner.getSelectedItemPosition() == 0) {
            Toast.makeText(getContext(), "Fuel Type cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (insuranceNo.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Insurance No cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (insuranceProvider.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Insurance Provider cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (insuranceStartDate.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Insurance Start Date cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (insuranceEndDate.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Insurance End Date cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (insuranceCoverage.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Insurance Coverage cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
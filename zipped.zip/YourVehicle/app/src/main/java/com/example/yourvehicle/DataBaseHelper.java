package com.example.yourvehicle;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "YourVehicle.db";
    private static final int DATABASE_VERSION = 1;

    // User Table
    private static final String TABLE_USER = "User";
    private static final String KEY_USER_ID = "uid";
    private static final String KEY_USER_NAME = "Uname";
    private static final String KEY_USER_ADDRESS = "Address";
    private static final String KEY_USER_LICENSE = "UserLicence";
    private static final String KEY_USER_USERNAME = "Username";
    private static final String KEY_USER_EMAIL = "email";
    private static final String KEY_USER_DOB = "DOB";
    private static final String KEY_USER_CONTACT_INFO = "Contact_info";
    private static final String KEY_USER_INSURANCE_CERTIFICATE = "Insurance_certificate";

    // Vehicle Table
    private static final String TABLE_VEHICLE = "Vehicle";
    private static final String KEY_VEHICLE_ID = "Vid";
    private static final String KEY_VEHICLE_CATEGORY = "Vehicle_Category";
    private static final String KEY_VEHICLE_USER_ID = "user_id"; // Foreign Key

    // TWO-Wheeler Table
    private static final String TABLE_TWO_WHEELER = "TWO-Wheeler";
    private static final String KEY_TWO_WHEELER_ID = "Tid";
    private static final String KEY_TWO_WHEELER_VEHICLE_ID = "vehicle_id"; // Foreign Key
    private static final String KEY_TWO_WHEELER_MAKE = "Make";
    private static final String KEY_TWO_WHEELER_MODEL = "Model";
    private static final String KEY_TWO_WHEELER_FUEL_TYPE = "Fuel_Type";
    private static final String KEY_TWO_WHEELER_KM_RUN = "Km_run";
    private static final String KEY_TWO_WHEELER_ENGINE = "Engine";
    private static final String KEY_TWO_WHEELER_DATE_OF_MANUFACTURE = "Date_of_manufacture";

    // FOUR-Wheeler Table
    private static final String TABLE_FOUR_WHEELER = "FOUR-Wheeler";
    private static final String KEY_FOUR_WHEELER_ID = "Fid";
    private static final String KEY_FOUR_WHEELER_VEHICLE_ID = "vehicle_id"; // Foreign Key
    private static final String KEY_FOUR_WHEELER_MAKE = "Make";
    private static final String KEY_FOUR_WHEELER_MODEL = "Model";
    private static final String KEY_FOUR_WHEELER_FUEL_TYPE = "Fuel_Type";
    private static final String KEY_FOUR_WHEELER_KM_RUN = "Km_run";
    private static final String KEY_FOUR_WHEELER_ENGINE_TYPE = "Engine_Type";
    private static final String KEY_FOUR_WHEELER_DATE_OF_PURCHASE = "Date_of_Purchase";

    public DataBaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USER + "("
                + KEY_USER_ID + " INTEGER PRIMARY KEY,"
                + KEY_USER_NAME + " TEXT,"
                + KEY_USER_ADDRESS + " TEXT,"
                + KEY_USER_LICENSE + " TEXT,"
                + KEY_USER_USERNAME + " TEXT,"
                + KEY_USER_EMAIL + " TEXT,"
                + KEY_USER_DOB + " TEXT,"
                + KEY_USER_CONTACT_INFO + " TEXT,"
                + KEY_USER_INSURANCE_CERTIFICATE + " TEXT" + ")";
        db.execSQL(CREATE_USER_TABLE);

        String CREATE_VEHICLE_TABLE = "CREATE TABLE " + TABLE_VEHICLE + "("
                + KEY_VEHICLE_ID + " INTEGER PRIMARY KEY,"
                + KEY_VEHICLE_CATEGORY + " TEXT,"
                + KEY_VEHICLE_USER_ID + " INTEGER,"
                + "FOREIGN KEY(" + KEY_VEHICLE_USER_ID + ") REFERENCES " + TABLE_USER + "(" + KEY_USER_ID + ")" + ")";
        db.execSQL(CREATE_VEHICLE_TABLE);

        String CREATE_TWO_WHEELER_TABLE = "CREATE TABLE " + TABLE_TWO_WHEELER + "("
                + KEY_TWO_WHEELER_ID + " INTEGER PRIMARY KEY,"
                + KEY_TWO_WHEELER_VEHICLE_ID + " INTEGER,"
                + KEY_TWO_WHEELER_MAKE + " TEXT,"
                + KEY_TWO_WHEELER_MODEL + " TEXT,"
                + KEY_TWO_WHEELER_FUEL_TYPE + " TEXT,"
                + KEY_TWO_WHEELER_KM_RUN + " INTEGER,"
                + KEY_TWO_WHEELER_ENGINE + " TEXT,"
                + KEY_TWO_WHEELER_DATE_OF_MANUFACTURE + " TEXT,"
                + "FOREIGN KEY(" + KEY_TWO_WHEELER_VEHICLE_ID + ") REFERENCES " + TABLE_VEHICLE + "(" + KEY_VEHICLE_ID + ")" + ")";
        db.execSQL(CREATE_TWO_WHEELER_TABLE);

        String CREATE_FOUR_WHEELER_TABLE = "CREATE TABLE " + TABLE_FOUR_WHEELER + "("
                + KEY_FOUR_WHEELER_ID + " INTEGER PRIMARY KEY,"
                + KEY_FOUR_WHEELER_VEHICLE_ID + " INTEGER,"
                + KEY_FOUR_WHEELER_MAKE + " TEXT,"
                + KEY_FOUR_WHEELER_MODEL + " TEXT,"
                + KEY_FOUR_WHEELER_FUEL_TYPE + " TEXT,"
                + KEY_FOUR_WHEELER_KM_RUN + " INTEGER,"
                + KEY_FOUR_WHEELER_ENGINE_TYPE + " TEXT,"
                + KEY_FOUR_WHEELER_DATE_OF_PURCHASE + " TEXT,"
                + "FOREIGN KEY(" + KEY_FOUR_WHEELER_VEHICLE_ID + ") REFERENCES " + TABLE_VEHICLE + "(" + KEY_VEHICLE_ID + ")" + ")";
        db.execSQL(CREATE_FOUR_WHEELER_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VEHICLE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TWO_WHEELER);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FOUR_WHEELER);
        onCreate(db);
    }
}
package com.example.yourvehicle;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class UserSection extends AppCompatActivity {
    private static final String PREFS_NAME = "MyPrefs";
    private static final String IS_USER_LOGGED_IN = "isUserLoggedIn";
    private static final String EXTRA_MESSAGE = "msg";
    private ImageView backBtn, logoutBtn;
    private BottomNavigationView bottomNavigationView;
    String fbEmail = null;
    private FirebaseAuth mAuth;
    private Vehicle vehicle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_user_section);

        setupWindowInsets();
        setupBackButton();
        setupBottomNavigation();
        setupEditProfileButton();
        handleIntentExtras();

        mAuth = FirebaseAuth.getInstance();

        Intent intentdb = getIntent();
        fbEmail = intentdb.getStringExtra("fbEmail");
        vehicle = (Vehicle) intentdb.getSerializableExtra("vehicleObj");

        if (vehicle != null) {
            bindVehicleInfoToViews(vehicle);
        } else {
            Toast.makeText(this, "Vehicle information not found", Toast.LENGTH_SHORT).show();
        }
    }

    private void bindVehicleInfoToViews(Vehicle vehicle) {
        bindTextViewById(R.id.TextUserName, vehicle.getUserName());
        bindTextViewById(R.id.TextUserEmail, vehicle.getEmail());
        bindTextViewById(R.id.TextUserPhone, vehicle.getPhone());
        bindTextViewById(R.id.TextUserAddress, vehicle.getAddress());
    }

    private void bindTextViewById(int viewId, String text) {
        TextView textView = findViewById(viewId);
        if (textView != null) {
            textView.setText(text);
        }
    }

    private void setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void setupBackButton() {
        backBtn = findViewById(R.id.back_btn);
        logoutBtn = findViewById(R.id.logout_btn);
        backBtn.setOnClickListener(v -> navigateTo(Dashboard.class));
        logoutBtn.setOnClickListener(view -> {
            mAuth.signOut();
            // Clear shared preferences
            SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putBoolean(IS_USER_LOGGED_IN, false);
            editor.apply();

            // Show a toast message
            Toast.makeText(this, "You have been logged out", Toast.LENGTH_SHORT).show();

            // Navigate to the LoginScreen
            navigateTo(LoginScreen.class);
        });
    }

    private void setupBottomNavigation() {
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.navigation_home) {
                navigateTo(Dashboard.class);
                return true;
            } else if (item.getItemId() == R.id.navigation_switch) {
                // Handle Switch item selection
                return true;
            } else if (item.getItemId() == R.id.navigation_add) {
                // Handle Add item selection
                return true;
            }
            return false;
        });
    }

    private void setupEditProfileButton() {
        findViewById(R.id.editName).setOnClickListener(v -> {
            // Pass fbEmail to the fragment
            replaceFragment(new FragNameEdit(), fbEmail, "EditUserName");
        });
        findViewById(R.id.emailEdit).setOnClickListener(v -> {
            // Pass fbEmail to the fragment
            replaceFragment(new FragNameEdit(), fbEmail, "EditUserEmail");
        });
        findViewById(R.id.editPhone).setOnClickListener(view -> {
            // Pass fbEmail to the fragment
            replaceFragment(new FragNameEdit(), fbEmail, "EditUserPhone");
        });
        findViewById(R.id.editAddress).setOnClickListener(view -> {
            // Pass fbEmail to the fragment
            replaceFragment(new FragNameEdit(), fbEmail, "EditUserAddress");
        });
    }

    private void handleIntentExtras() {
        Intent intent = getIntent();
        if (intent != null && intent.getStringExtra(EXTRA_MESSAGE) != null) {
            Toast.makeText(this, intent.getStringExtra(EXTRA_MESSAGE), Toast.LENGTH_SHORT).show();
        }
    }

    private void replaceFragment(Fragment fragment, String fbEmail, String other) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        // Pass fbEmail to the fragment
        Bundle bundle = new Bundle();
        bundle.putString("fbEmail", fbEmail);
        bundle.putString("other", other);
        fragment.setArguments(bundle);

        fragmentTransaction.replace(R.id.fragmentContainer, fragment);
        fragmentTransaction.commit();
    }

    private void navigateTo(Class<?> cls) {
        Intent intent = new Intent(this, cls);
        intent.putExtra("fbEmail", fbEmail);
        startActivity(intent);
        finish();
    }
}
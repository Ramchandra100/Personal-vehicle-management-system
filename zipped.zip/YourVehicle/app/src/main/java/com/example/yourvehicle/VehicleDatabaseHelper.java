package com.example.yourvehicle;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class VehicleDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "yourvehicle_db";
    private static final int DATABASE_VERSION = 1;
    private static int shuffleCount = 1;

    public static final String TABLE_VEHICLE = "vehicle";
    public static final String COLUMN_ID = "_id";
    private static final String COLUMN_PHONE = "phone";
    public static final String COLUMN_MODEL_NO = "model_no";
    public static final String COLUMN_VEHICLE_TYPE = "vehicle_type";
    public static final String COLUMN_vehicleNo = "vehicleNo";
    public static final String COLUMN_COLOR = "color";
    public static final String COLUMN_KMS = "kms";
    public static final String COLUMN_FUEL_TYPE = "fuel_type";
    public static final String COLUMN_LICENCE_NO = "licence_no";
    public static final String COLUMN_ISSUE_DATE = "issue_date";
    public static final String COLUMN_EXPIRY_DATE = "expiry_date";
    public static final String COLUMN_ADDRESS = "address";
    public static final String COLUMN_PUC_ISSUE_DATE = "puc_issue_date";
    public static final String COLUMN_PUC_EXPIRY_DATE = "puc_expiry_date";
    public static final String COLUMN_CO_LEVEL = "co_level";
    public static final String COLUMN_STATUS = "status";
    public static final String COLUMN_LAST_SERVICE_DATE = "last_service_date";
    public static final String COLUMN_SERVICE_AMOUNT = "service_amount";
    public static final String COLUMN_SERVICE_TYPE = "service_type";
    public static final String COLUMN_USER_NAME = "user_name";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_INSURANCE_NO = "insurance_no";
    public static final String COLUMN_INSURANCE_PROVIDER = "insurance_provider";
    public static final String COLUMN_INSURANCE_START_DATE = "insurance_start_date";
    public static final String COLUMN_INSURANCE_END_DATE = "insurance_end_date";
    public static final String COLUMN_INSURANCE_COVERAGE = "insurance_coverage";
    public static final String COLUMN_FINE_DATE = "fine_date";
    public static final String COLUMN_TOTAL_FINE = "total_fine";

    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_VEHICLE + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_MODEL_NO + " TEXT, " +
                    COLUMN_vehicleNo + " TEXT, " +
                    COLUMN_COLOR + " TEXT, " +
                    COLUMN_KMS + " TEXT, " +
                    COLUMN_FUEL_TYPE + " TEXT, " +
                    COLUMN_LICENCE_NO + " TEXT, " +
                    COLUMN_ISSUE_DATE + " TEXT, " +
                    COLUMN_EXPIRY_DATE + " TEXT, " +
                    COLUMN_ADDRESS + " TEXT, " +
                    COLUMN_PUC_ISSUE_DATE + " TEXT, " +
                    COLUMN_PUC_EXPIRY_DATE + " TEXT, " +
                    COLUMN_CO_LEVEL + " TEXT, " +
                    COLUMN_STATUS + " TEXT, " +
                    COLUMN_LAST_SERVICE_DATE + " TEXT, " +
                    COLUMN_SERVICE_AMOUNT + " TEXT, " +
                    COLUMN_USER_NAME + " TEXT, " +
                    COLUMN_EMAIL + " TEXT, " +
                    COLUMN_PASSWORD + " TEXT, " +
                    COLUMN_VEHICLE_TYPE + " TEXT, " +
                    COLUMN_SERVICE_TYPE + " TEXT, " +
                    COLUMN_INSURANCE_NO + " TEXT, " +
                    COLUMN_INSURANCE_PROVIDER + " TEXT, " +
                    COLUMN_INSURANCE_START_DATE + " TEXT, " +
                    COLUMN_INSURANCE_END_DATE + " TEXT, " +
                    COLUMN_TOTAL_FINE + " TEXT, " +
                    COLUMN_FINE_DATE + " TEXT, " +
                    COLUMN_PHONE + " TEXT, " +
                    COLUMN_INSURANCE_COVERAGE + " TEXT" +
                    ");";

    public VehicleDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);

        // Add actual data
        ContentValues values1 = new ContentValues();
        values1.put(COLUMN_MODEL_NO, "Mahindra BE 6");
        values1.put(COLUMN_vehicleNo, "MH12BE6001"); // Example vehicle number
        values1.put(COLUMN_COLOR, "Napoli Black"); // Actual color from the webpage
        values1.put(COLUMN_KMS, "0"); // Assuming a new vehicle
        values1.put(COLUMN_FUEL_TYPE, "Electric"); // Actual fuel type
        values1.put(COLUMN_LICENCE_NO, "LIC12345"); // Example license number
        values1.put(COLUMN_ISSUE_DATE, "2025-04-02"); // Example issue date
        values1.put(COLUMN_EXPIRY_DATE, "2026-04-02"); // Example expiry date
        values1.put(COLUMN_ADDRESS, "123 Main St"); // Example address
        values1.put(COLUMN_PUC_ISSUE_DATE, "2025-04-02"); // Example PUC issue date
        values1.put(COLUMN_PUC_EXPIRY_DATE, "2026-04-02"); // Example PUC expiry date
        values1.put(COLUMN_CO_LEVEL, "0.0"); // Electric vehicles do not emit CO
        values1.put(COLUMN_STATUS, "Active");
        values1.put(COLUMN_LAST_SERVICE_DATE, "2025-04-02"); // Example last service date
        values1.put(COLUMN_SERVICE_AMOUNT, "500"); // Example service amount
        values1.put(COLUMN_USER_NAME, "Ramchandra");
        values1.put(COLUMN_EMAIL, "phonepurpose29@gmail.com");
        values1.put(COLUMN_PASSWORD, "password123");
        values1.put(COLUMN_VEHICLE_TYPE, "CAR");
        values1.put(COLUMN_SERVICE_TYPE, "General");
        values1.put(COLUMN_INSURANCE_NO, "INS12345"); // Example insurance number
        values1.put(COLUMN_INSURANCE_PROVIDER, "ProviderA"); // Example provider
        values1.put(COLUMN_INSURANCE_START_DATE, "2025-04-02"); // Example insurance start date
        values1.put(COLUMN_INSURANCE_END_DATE, "2026-04-02"); // Example insurance end date
        values1.put(COLUMN_INSURANCE_COVERAGE, "Comprehensive");
        values1.put(COLUMN_TOTAL_FINE, "0"); // Assuming no fines
        values1.put(COLUMN_PHONE, "1234567890"); // Example phone number
        values1.put(COLUMN_FINE_DATE, "2025-04-02"); // Example fine date

        db.insert(TABLE_VEHICLE, null, values1);
// Add actual data
        ContentValues values2 = new ContentValues();
        values2.put(COLUMN_MODEL_NO, "Tata Curvv");
        values2.put(COLUMN_vehicleNo, "MH12CURVV001"); // Example vehicle number
        values2.put(COLUMN_COLOR, "Nitro Crimson"); // Actual color from the webpage
        values2.put(COLUMN_KMS, "0"); // Assuming a new vehicle
        values2.put(COLUMN_FUEL_TYPE, "Petrol"); // Actual fuel type
        values2.put(COLUMN_LICENCE_NO, "LIC67890"); // Example license number
        values2.put(COLUMN_ISSUE_DATE, "2025-04-02"); // Example issue date
        values2.put(COLUMN_EXPIRY_DATE, "2026-04-02"); // Example expiry date
        values2.put(COLUMN_ADDRESS, "456 Elm St"); // Example address
        values2.put(COLUMN_PUC_ISSUE_DATE, "2025-04-02"); // Example PUC issue date
        values2.put(COLUMN_PUC_EXPIRY_DATE, "2026-04-02"); // Example PUC expiry date
        values2.put(COLUMN_CO_LEVEL, "0.0"); // Petrol vehicles typically have lower CO emissions
        values2.put(COLUMN_STATUS, "Active");
        values2.put(COLUMN_LAST_SERVICE_DATE, "2025-04-02"); // Example last service date
        values2.put(COLUMN_SERVICE_AMOUNT, "700"); // Example service amount
        values2.put(COLUMN_USER_NAME, "JaneDoe");
        values2.put(COLUMN_EMAIL, "phonepurpose29@gmail.com");
        values2.put(COLUMN_PASSWORD, "password456");
        values2.put(COLUMN_VEHICLE_TYPE, "CAR");
        values2.put(COLUMN_SERVICE_TYPE, "General");
        values2.put(COLUMN_INSURANCE_NO, "INS67890"); // Example insurance number
        values2.put(COLUMN_INSURANCE_PROVIDER, "ProviderB"); // Example provider
        values2.put(COLUMN_INSURANCE_START_DATE, "2025-04-02"); // Example insurance start date
        values2.put(COLUMN_INSURANCE_END_DATE, "2026-04-02"); // Example insurance end date
        values2.put(COLUMN_INSURANCE_COVERAGE, "Comprehensive");
        values2.put(COLUMN_TOTAL_FINE, "0"); // Assuming no fines
        values2.put(COLUMN_FINE_DATE, "2025-04-02"); // Example fine date
        values2.put(COLUMN_PHONE, "9876543210"); // Example phone number

        db.insert(TABLE_VEHICLE, null, values2);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 1) {
            db.execSQL("ALTER TABLE " + TABLE_VEHICLE + " ADD COLUMN new_column TEXT");
        }
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_VEHICLE);
        onCreate(db);
    }

    public String getUserByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        String rawQuery = "SELECT " + COLUMN_USER_NAME + " FROM " + TABLE_VEHICLE + " WHERE " + COLUMN_EMAIL + " = ?";
        String[] selectionArgs = {email};
        Cursor cursor = db.rawQuery(rawQuery, selectionArgs);

        if (cursor != null && cursor.moveToFirst()) {
            // User exists, return the username
            String userName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_NAME));
            cursor.close();
            db.close();
            return userName; // Return the existing username
        } else {
            // User does not exist, create a new row with default values
            ContentValues values = new ContentValues();
            values.put(COLUMN_EMAIL, "phonepurpose29@gmail.com"); // Example email
            values.put(COLUMN_MODEL_NO, "Tata Curvv");
            values.put(COLUMN_vehicleNo, "MH12CURVV001"); // Example vehicle number
            values.put(COLUMN_COLOR, "Nitro Crimson"); // Actual color from the webpage
            values.put(COLUMN_KMS, "0"); // Assuming a new vehicle
            values.put(COLUMN_FUEL_TYPE, "Petrol"); // Actual fuel type
            values.put(COLUMN_LICENCE_NO, "LIC67890"); // Example license number
            values.put(COLUMN_ISSUE_DATE, "2025-04-02"); // Example issue date
            values.put(COLUMN_EXPIRY_DATE, "2026-04-02"); // Example expiry date
            values.put(COLUMN_ADDRESS, "456 Elm St"); // Example address
            values.put(COLUMN_PUC_ISSUE_DATE, "2025-04-02"); // Example PUC issue date
            values.put(COLUMN_PUC_EXPIRY_DATE, "2026-04-02"); // Example PUC expiry date
            values.put(COLUMN_CO_LEVEL, "0.0"); // Petrol vehicles typically have lower CO emissions
            values.put(COLUMN_STATUS, "Active");
            values.put(COLUMN_LAST_SERVICE_DATE, "2025-04-02"); // Example last service date
            values.put(COLUMN_SERVICE_AMOUNT, "700"); // Example service amount
            values.put(COLUMN_USER_NAME, "JaneDoe");
            values.put(COLUMN_PASSWORD, "password456");
            values.put(COLUMN_VEHICLE_TYPE, "CAR");
            values.put(COLUMN_SERVICE_TYPE, "General");
            values.put(COLUMN_INSURANCE_NO, "INS67890"); // Example insurance number
            values.put(COLUMN_INSURANCE_PROVIDER, "ProviderB"); // Example provider
            values.put(COLUMN_INSURANCE_START_DATE, "2025-04-02"); // Example insurance start date
            values.put(COLUMN_INSURANCE_END_DATE, "2026-04-02"); // Example insurance end date
            values.put(COLUMN_INSURANCE_COVERAGE, "Comprehensive");
            values.put(COLUMN_TOTAL_FINE, "0"); // Assuming no fines
            values.put(COLUMN_FINE_DATE, "2025-04-02"); // Example fine date
            values.put(COLUMN_PHONE, "9876543210"); // Example phone number

// You can set other default values here if needed
            long newRowId = db.insert(TABLE_VEHICLE, null, values);
            db.close();
            return email; // Return the default username
        }
    }

    public String addUser(String userName, String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        String result = "Error";

        // Check if the user already exists
        String checkUserQuery = "SELECT " + COLUMN_USER_NAME + " FROM " + TABLE_VEHICLE + " WHERE " + COLUMN_EMAIL + " = ?";
        Cursor cursor = db.rawQuery(checkUserQuery, new String[]{email});

        if (cursor != null && cursor.moveToFirst()) {
            // User exists, update the existing record
//            ContentValues values = new ContentValues();
//            values.put(COLUMN_USER_NAME, userName);
//            values.put(COLUMN_PASSWORD, password);
//
//            String selection = COLUMN_EMAIL + " = ?";
//            String[] selectionArgs = {email};
//
//            int rowsUpdated = db.update(TABLE_VEHICLE, values, selection, selectionArgs);
//            if (rowsUpdated > 0) {
//                result = "User updated successfully";
//            } else {
//                result = "Failed to update user";
//            }
        } else {
            // User does not exist, create a new record
            ContentValues values = new ContentValues();
            values.put(COLUMN_USER_NAME, userName);
            values.put(COLUMN_EMAIL, email);
            values.put(COLUMN_PASSWORD, password);
            values.put(COLUMN_MODEL_NO, "Tata Curvv");
            values.put(COLUMN_vehicleNo, "UVW789");
            values.put(COLUMN_COLOR, "Blue");
            values.put(COLUMN_KMS, "10000");
            values.put(COLUMN_FUEL_TYPE, "Diesel");
            values.put(COLUMN_LICENCE_NO, "LIC67890");
            values.put(COLUMN_ISSUE_DATE, "2022-05-01");
            values.put(COLUMN_EXPIRY_DATE, "2023-05-01");
            values.put(COLUMN_ADDRESS, "456 Elm St");
            values.put(COLUMN_PUC_ISSUE_DATE, "2022-06-01");
            values.put(COLUMN_PUC_EXPIRY_DATE, "2023-06-01");
            values.put(COLUMN_CO_LEVEL, "0.3");
            values.put(COLUMN_STATUS, "Inactive");
            values.put(COLUMN_LAST_SERVICE_DATE, "2022-07-01");
            values.put(COLUMN_SERVICE_AMOUNT, "700");
            values.put(COLUMN_VEHICLE_TYPE, "Truck");
            values.put(COLUMN_SERVICE_TYPE, "General");
            values.put(COLUMN_INSURANCE_NO, "INS67890");
            values.put(COLUMN_INSURANCE_PROVIDER, "ProviderB");
            values.put(COLUMN_INSURANCE_START_DATE, "2022-08-01");
            values.put(COLUMN_INSURANCE_END_DATE, "2023-08-01");
            values.put(COLUMN_INSURANCE_COVERAGE, "Third Party");
            values.put(COLUMN_TOTAL_FINE, "1000");
            values.put(COLUMN_FINE_DATE, "2023-05-01");
            values.put(COLUMN_PHONE, "9876543210");

            long newRowId = db.insert(TABLE_VEHICLE, null, values);
            if (newRowId != -1) {
                result = "User added successfully";
            } else {
                result = "Failed to add user";
            }
        }

        if (cursor != null) {
            cursor.close();
        }
        db.close();
        return result;
    }


    public Vehicle getVehicleOject(String fbEmail) {
        SQLiteDatabase db = this.getReadableDatabase();
        Vehicle vehicle = null;

        // Query to get the vehicle information for the given email
        String query = "SELECT * FROM " + TABLE_VEHICLE + " WHERE " + COLUMN_EMAIL + " = ?";
        Cursor cursor = db.rawQuery(query, new String[]{fbEmail});
        if(cursor.getCount()<shuffleCount){
            shuffleCount=1;
        }

        if (cursor != null && cursor.move(shuffleCount)) {
            // Create a new Vehicle object and set its properties
            vehicle = new Vehicle();
            vehicle.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
            vehicle.setModelNo(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_MODEL_NO)));
            vehicle.setvehicleNo(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_vehicleNo)));
            vehicle.setColor(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_COLOR)));
            vehicle.setKms(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_KMS)));
            vehicle.setFuelType(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_FUEL_TYPE)));
            vehicle.setLicenceNo(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_LICENCE_NO)));
            vehicle.setIssueDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ISSUE_DATE)));
            vehicle.setExpiryDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EXPIRY_DATE)));
            vehicle.setAddress(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ADDRESS)));
            vehicle.setPucIssueDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PUC_ISSUE_DATE)));
            vehicle.setPucExpiryDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PUC_EXPIRY_DATE)));
            vehicle.setCoLevel(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_CO_LEVEL)));
            vehicle.setStatus(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_STATUS)));
            vehicle.setLastServiceDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_LAST_SERVICE_DATE)));
            vehicle.setServiceAmount(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SERVICE_AMOUNT)));
            vehicle.setServiceType(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_SERVICE_TYPE)));
            vehicle.setVehicleType(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VEHICLE_TYPE)));
            vehicle.setInsuranceNo(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_INSURANCE_NO)));
            vehicle.setInsuranceProvider(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_INSURANCE_PROVIDER)));
            vehicle.setInsuranceStartDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_INSURANCE_START_DATE)));
            vehicle.setInsuranceEndDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_INSURANCE_END_DATE)));
            vehicle.setInsuranceCoverage(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_INSURANCE_COVERAGE)));
            vehicle.setUserName(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USER_NAME))); // Set userName
            vehicle.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL)));       // Set email
            vehicle.setPassword(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PASSWORD))); // Set password
            vehicle.setTotalFine(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TOTAL_FINE)));
            vehicle.setFineDate(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_FINE_DATE)));
            vehicle.setPhone(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHONE)));
        }

        if (cursor != null) {
            cursor.close();
        }
        db.close();

        return vehicle;
    }

    public void shuffleRowsForEmail(String email) {
        shuffleCount += 1;
    }

    public long insertVehicle(Vehicle vehicle, String email) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_EMAIL, email);
        values.put(COLUMN_MODEL_NO, vehicle.getModelNo());
        values.put(COLUMN_vehicleNo, vehicle.getvehicleNo());
        values.put(COLUMN_COLOR, vehicle.getColor());
        values.put(COLUMN_KMS, vehicle.getKms());
        values.put(COLUMN_FUEL_TYPE, vehicle.getFuelType());
        values.put(COLUMN_LICENCE_NO, vehicle.getLicenceNo());
        values.put(COLUMN_ISSUE_DATE, vehicle.getIssueDate());
        values.put(COLUMN_EXPIRY_DATE, vehicle.getExpiryDate());
        values.put(COLUMN_ADDRESS, vehicle.getAddress());
        values.put(COLUMN_PUC_ISSUE_DATE, vehicle.getPucIssueDate());
        values.put(COLUMN_PUC_EXPIRY_DATE, vehicle.getPucExpiryDate());
        values.put(COLUMN_CO_LEVEL, vehicle.getCoLevel());
        values.put(COLUMN_STATUS, vehicle.getStatus());
        values.put(COLUMN_LAST_SERVICE_DATE, vehicle.getLastServiceDate());
        values.put(COLUMN_SERVICE_AMOUNT, vehicle.getServiceAmount());
        values.put(COLUMN_SERVICE_TYPE, vehicle.getServiceType());
        values.put(COLUMN_VEHICLE_TYPE, vehicle.getVehicleType());
        values.put(COLUMN_INSURANCE_NO, vehicle.getInsuranceNo());
        values.put(COLUMN_INSURANCE_PROVIDER, vehicle.getInsuranceProvider());
        values.put(COLUMN_INSURANCE_START_DATE, vehicle.getInsuranceStartDate());
        values.put(COLUMN_INSURANCE_END_DATE, vehicle.getInsuranceEndDate());
        values.put(COLUMN_INSURANCE_COVERAGE, vehicle.getInsuranceCoverage());
        values.put(COLUMN_TOTAL_FINE, vehicle.getTotalFine());
        values.put(COLUMN_FINE_DATE, vehicle.getFineDate());
        values.put(COLUMN_VEHICLE_TYPE, vehicle.getVehicleType());
        values.put(COLUMN_USER_NAME, vehicle.getUserName());
        values.put(COLUMN_PHONE, vehicle.getPhone());

        long newRowId = db.insert(TABLE_VEHICLE, null, values);
        db.close();
        return newRowId;
    }

    public String editUserName(String email, String newUserName) {
        SQLiteDatabase db = this.getWritableDatabase();
        String result = "Error";

        // Check if the user exists
        String checkUserQuery = "SELECT " + COLUMN_USER_NAME + " FROM " + TABLE_VEHICLE + " WHERE " + COLUMN_EMAIL + " = ?";
        Cursor cursor = db.rawQuery(checkUserQuery, new String[]{email});

        if (cursor != null && cursor.move(shuffleCount)) {
            // User exists, update the user name
            ContentValues values = new ContentValues();
            values.put(COLUMN_USER_NAME, newUserName);
            String selection = COLUMN_EMAIL + " = ?";
            String[] selectionArgs = {email};

            int rowsUpdated = db.update(TABLE_VEHICLE, values, selection, selectionArgs);
            if (rowsUpdated > 0) {
                result = "User name updated successfully";
            } else {
                result = "Failed to update user name";
            }
        } else {
            // User does not exist
            result = "User not found";
        }

        if (cursor != null) {
            cursor.close();
        }
        db.close();
        return result;
    }

    public String editEmail(String email, String newEmail) {
        SQLiteDatabase db = this.getWritableDatabase();
        String result = "Error";

        ContentValues values = new ContentValues();
        values.put(COLUMN_EMAIL, newEmail);

        String selection = COLUMN_EMAIL + " = ?";
        String[] selectionArgs = {email};

        int rowsUpdated = db.update(TABLE_VEHICLE, values, selection, selectionArgs);
        if (rowsUpdated > 0) {
            result = "Email updated successfully";
        } else {
            result = "Failed to update email";
        }
        db.close();
        return result;
    }

    public String editPhone(String email, String newPhone) {
        SQLiteDatabase db = this.getWritableDatabase();
        String result = "Error";

        ContentValues values = new ContentValues();
        values.put(COLUMN_PHONE, newPhone);

        String selection = COLUMN_EMAIL + " = ?";
        String[] selectionArgs = {email};

        int rowsUpdated = db.update(TABLE_VEHICLE, values, selection, selectionArgs);
        if (rowsUpdated > 0) {
            result = "Phone number updated successfully";
        } else {
            result = "Failed to update phone number";
        }
        db.close();
        return result;
    }

    public String editAddress(String email, String newAddress) {
        SQLiteDatabase db = this.getWritableDatabase();
        String result = "Error";

        ContentValues values = new ContentValues();
        values.put(COLUMN_ADDRESS, newAddress);

        String selection = COLUMN_EMAIL + " = ?";
        String[] selectionArgs = {email};

        int rowsUpdated = db.update(TABLE_VEHICLE, values, selection, selectionArgs);
        if (rowsUpdated > 0) {
            result = "Address updated successfully";
        } else {
            result = "Failed to update address";
        }
        db.close();
        return result;
    }

    public int updateVehicle(Vehicle vehicle, String fbEmail) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // Set the updated values
        values.put(COLUMN_MODEL_NO, vehicle.getModelNo());
        values.put(COLUMN_vehicleNo, vehicle.getvehicleNo());
        values.put(COLUMN_COLOR, vehicle.getColor());
        values.put(COLUMN_KMS, vehicle.getKms());
        values.put(COLUMN_FUEL_TYPE, vehicle.getFuelType());
        values.put(COLUMN_LICENCE_NO, vehicle.getLicenceNo());
        values.put(COLUMN_ISSUE_DATE, vehicle.getIssueDate());
        values.put(COLUMN_EXPIRY_DATE, vehicle.getExpiryDate());
        values.put(COLUMN_ADDRESS, vehicle.getAddress());
        values.put(COLUMN_PUC_ISSUE_DATE, vehicle.getPucIssueDate());
        values.put(COLUMN_PUC_EXPIRY_DATE, vehicle.getPucExpiryDate());
        values.put(COLUMN_CO_LEVEL, vehicle.getCoLevel());
        values.put(COLUMN_STATUS, vehicle.getStatus());
        values.put(COLUMN_LAST_SERVICE_DATE, vehicle.getLastServiceDate());
        values.put(COLUMN_SERVICE_AMOUNT, vehicle.getServiceAmount());
        values.put(COLUMN_SERVICE_TYPE, vehicle.getServiceType());
        values.put(COLUMN_VEHICLE_TYPE, vehicle.getVehicleType());
        values.put(COLUMN_INSURANCE_NO, vehicle.getInsuranceNo());
        values.put(COLUMN_INSURANCE_PROVIDER, vehicle.getInsuranceProvider());
        values.put(COLUMN_INSURANCE_START_DATE, vehicle.getInsuranceStartDate());
        values.put(COLUMN_INSURANCE_END_DATE, vehicle.getInsuranceEndDate());
        values.put(COLUMN_INSURANCE_COVERAGE, vehicle.getInsuranceCoverage());
        values.put(COLUMN_TOTAL_FINE, vehicle.getTotalFine());
        values.put(COLUMN_FINE_DATE, vehicle.getFineDate());
        values.put(COLUMN_USER_NAME, vehicle.getUserName());
        values.put(COLUMN_PHONE, vehicle.getPhone());

        // Update the row where the email matches
        String selection = COLUMN_EMAIL + " = ?";
        String[] selectionArgs = {fbEmail};

        int rowsUpdated = db.update(TABLE_VEHICLE, values, selection, selectionArgs);
        db.close();
        return  rowsUpdated;
    }
}
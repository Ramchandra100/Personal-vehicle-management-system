package com.example.yourvehicle;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.util.Calendar;
import java.util.Objects;

public class AddingSectionInputThree extends Fragment {
    private EditText totalFine,  status, serviceAmount, serviceType;
    private Vehicle vehicle;
    private VehicleDatabaseHelper dbHelper;
    private TextView fineDate,lastService;
    String fbEmail,check="no";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.adding_section_input_three, container, false);

        totalFine = view.findViewById(R.id.TotalFine);
        fineDate = view.findViewById(R.id.FineDate);
        status = view.findViewById(R.id.Status);
        lastService = view.findViewById(R.id.Lastservice);
        serviceAmount = view.findViewById(R.id.serviceAmount);
        serviceType = view.findViewById(R.id.ServiceType);

        Button saveButton = view.findViewById(R.id.login_button7);
        fineDate.setOnClickListener(v -> showDatePickerDialog(fineDate));
        lastService.setOnClickListener(v -> showDatePickerDialog(lastService));

        Bundle arguments = getArguments();
        assert arguments != null;
        fbEmail = arguments.getString("fbEmail");
        if (arguments.getString("update") != null && Objects.equals(arguments.getString("update"), "update")) {
            vehicle = (Vehicle) arguments.getSerializable("vehicle");
            check = arguments.getString("update");
            bindEditTexts(totalFine, vehicle.getTotalFine());
            fineDate.setText(vehicle.getFineDate());
            lastService.setText(vehicle.getLastServiceDate());
            bindEditTexts(status, vehicle.getStatus());
            bindEditTexts(serviceAmount, vehicle.getServiceAmount());
            bindEditTexts(serviceType, vehicle.getServiceType());
        }else{
            vehicle = (Vehicle) arguments.getSerializable("vehicle");
        }

        saveButton.setOnClickListener(v -> {
            if (validateInput()) {
                saveVehicleData();
            }
        });

        dbHelper = new VehicleDatabaseHelper(getContext());

        Button backButton = view.findViewById(R.id.login_button6);
        backButton.setOnClickListener(view1 -> {
            Bundle newBundle = new Bundle();
            Bundle bundleRetrive = getArguments();
            if (bundleRetrive != null) {
                String fbEmail = bundleRetrive.getString("fbEmail");
                newBundle.putString("fbEmail", fbEmail);
            }
            if(check.equals("update")){
                newBundle.putString("update","update");
            }
            newBundle.putSerializable("vehicle", vehicle);
            AddingSectionInputTwo fragment = new AddingSectionInputTwo();
            fragment.setArguments(newBundle);
            getParentFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainer, fragment)
                    .addToBackStack(null)
                    .commit();
        });

        return view;
    }

    private void bindEditTexts(EditText ed, String text) {
        ed.setText(text);
    }

    private void showDatePickerDialog(TextView textView) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                requireContext(),
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        // Handle the selected date
                        textView.setText(year + "-" + (month + 1) + "-" + year);
                    }
                },
                year,
                month,
                day
        );

        datePickerDialog.show();
    }

    private boolean validateInput() {
        if (totalFine.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Total Fine cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (fineDate.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Fine Date cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (status.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Status cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (lastService.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Last Service Date cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (serviceAmount.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Service Amount cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (serviceType.getText().toString().trim().isEmpty()) {
            Toast.makeText(getContext(), "Service Type cannot be empty", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private void saveVehicleData() {
        String totalFineText = totalFine.getText().toString().trim();
        String fineDateText = fineDate.getText().toString().trim();
        String statusText = status.getText().toString().trim();
        String lastServiceText = lastService.getText().toString().trim();
        String serviceAmountText = serviceAmount.getText().toString().trim();
        String serviceTypeText = serviceType.getText().toString().trim();

        vehicle.setStatus(statusText);
        vehicle.setLastServiceDate(lastServiceText);
        vehicle.setServiceAmount(serviceAmountText);
        vehicle.setServiceType(serviceTypeText);
        vehicle.setTotalFine(totalFineText);
        vehicle.setFineDate(fineDateText);

        Bundle bundleRetrive = getArguments();
        if (bundleRetrive != null) {
            String fbEmail = bundleRetrive.getString("fbEmail");
            String uname=dbHelper.getUserByEmail(fbEmail);
            vehicle.setUserName(uname);

            if(check.equals("update")){
               int rowsUpdated= dbHelper.updateVehicle(vehicle,fbEmail);
                if (rowsUpdated > 0) {
                    // Update was successful
                    Toast.makeText(getContext(), "Vehicle information updated successfully", Toast.LENGTH_SHORT).show();
                } else {
                    // Update failed
                    Toast.makeText(getContext(), "Failed to update vehicle information", Toast.LENGTH_SHORT).show();
                }
                Toast.makeText(getContext(), "Data updated successfully", Toast.LENGTH_SHORT).show();
                navigateTo(AddingSection.class);
                return;
            }else {
                long newRowId = dbHelper.insertVehicle(vehicle, fbEmail);

                if (newRowId != -1) {
                    Toast.makeText(getContext(), "Data saved successfully", Toast.LENGTH_SHORT).show();
                    navigateTo(AddingSection.class);
                } else {
                    Toast.makeText(getContext(), "Failed to save data", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void navigateTo(Class<?> cls) {
        Bundle bundleRetrive = getArguments();
        if (bundleRetrive != null) {
            String fbEmail = bundleRetrive.getString("fbEmail");
            Intent intent = new Intent(getContext(), cls);
            intent.putExtra("fbEmail", fbEmail);
            startActivity(intent);
        }
    }
}
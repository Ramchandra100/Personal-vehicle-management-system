package com.example.yourvehicle;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;

import java.util.Objects;

public class SignupScreen extends AppCompatActivity {
    private static final String PREFS_NAME = "MyPrefs";
    private static final String IS_USER_LOGGED_IN = "isUserLoggedIn";
    private static final int MIN_PASSWORD_LENGTH = 7;
    private EditText inputEmail, inputPassword, inputConfirmPassword,inputUserName;
    private ProgressBar progressBar;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_signup_screen);

        setupWindowInsets();
        initializeFirebaseAuth();
        initializeUIComponents();
        setupSignUpButton();
        setupAlreadyHaveAccountButton();
    }

    private void setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void initializeFirebaseAuth() {
        mAuth = FirebaseAuth.getInstance();
    }

    private void initializeUIComponents() {
        inputUserName=findViewById(R.id.username_signup);
        inputEmail = findViewById(R.id.email_signup);
        inputPassword = findViewById(R.id.pass_signup);
        inputConfirmPassword = findViewById(R.id.comfirm_pass_signup);
        progressBar = findViewById(R.id.progressBar2);
    }

    private void setupSignUpButton() {
        Button btnSignUp = findViewById(R.id.login_button);
        btnSignUp.setOnClickListener(v -> createAccount());
    }

    private void setupAlreadyHaveAccountButton() {
        Button alreadyHaveAccount = findViewById(R.id.dont_have_acc);
        alreadyHaveAccount.setOnClickListener(v -> navigateTo(LoginScreen.class));
    }

    private void createAccount() {
        String email = inputEmail.getText().toString().trim();
        String password = inputPassword.getText().toString().trim();
        String confirmPassword = inputConfirmPassword.getText().toString().trim();
        String userName=inputUserName.getText().toString().trim();

        if (!validateEmail(email)) return;
        if (!validatePassword(password)) return;
        if (!validateConfirmPassword(password, confirmPassword)) return;
        if (userName.isEmpty()) {
            inputUserName.setError("Enter User Name");
            inputUserName.requestFocus();
            return;
        }
        VehicleDatabaseHelper vehicleDatabaseHelper=new VehicleDatabaseHelper(this);
        vehicleDatabaseHelper.addUser(userName,email,password);

        progressBar.setVisibility(View.VISIBLE);
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    progressBar.setVisibility(View.GONE);
                    if (task.isSuccessful()) {
                        saveLoginStatus(true);
                        sendEmailVerification();
                        navigateTo(LoginScreen.class);
                    } else {
                        handleSignUpFailure(task.getException());
                    }
                });
    }

    private boolean validateEmail(String email) {
        if (email.isEmpty()) {
            inputEmail.setError("Enter Email Address");
            inputEmail.requestFocus();
            return false;
        }
        if (email.length() < 10) {
            inputEmail.setError("Enter A Valid Email Address");
            inputEmail.requestFocus();
            return false;
        }
        return true;
    }

    private boolean validatePassword(String password) {
        if (password.isEmpty()) {
            inputPassword.setError("Enter Password");
            inputPassword.requestFocus();
            return false;
        }
        if (password.length() < MIN_PASSWORD_LENGTH) {
            inputPassword.setError("Password should be at least " + MIN_PASSWORD_LENGTH + " characters");
            inputPassword.requestFocus();
            return false;
        }
        return true;
    }

    private boolean validateConfirmPassword(String password, String confirmPassword) {
        if (!password.equals(confirmPassword)) {
            inputConfirmPassword.setError("Passwords do not match");
            inputConfirmPassword.requestFocus();
            return false;
        }
        return true;
    }

    private void sendEmailVerification() {
        if (mAuth.getCurrentUser() != null) {
            mAuth.getCurrentUser().sendEmailVerification()
                    .addOnCompleteListener(this, task -> {
                        if (task.isSuccessful()) {
                            Toast.makeText(this, "Verification email sent", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(this, "Failed to send verification email", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    private void handleSignUpFailure(Exception e) {
        if (e instanceof FirebaseAuthInvalidCredentialsException) {
            inputPassword.setError("Invalid Password");
            inputPassword.requestFocus();
        } else if (e instanceof FirebaseAuthInvalidUserException) {
            inputEmail.setError("Invalid Email");
            inputEmail.requestFocus();
        } else {
            Toast.makeText(this, "Oops! Something went wrong: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void saveLoginStatus(boolean isLoggedIn) {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(IS_USER_LOGGED_IN, isLoggedIn);
        editor.apply();
    }

    private void navigateTo(Class<?> cls) {
        Intent intent = new Intent(this, cls);
        startActivity(intent);
        finish();
    }
}
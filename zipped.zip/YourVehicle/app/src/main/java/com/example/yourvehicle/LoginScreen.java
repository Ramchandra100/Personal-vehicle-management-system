package com.example.yourvehicle;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;

import java.util.Objects;

public class LoginScreen extends AppCompatActivity {
    private static final String PREFS_NAME = "MyPrefs";
    private static final String IS_USER_LOGGED_IN = "isUserLoggedIn";
    private static final int MIN_PASSWORD_LENGTH = 7;
    private EditText inputEmail, inputPassword,inputUserName;
    private FirebaseAuth mAuth;
    String fbEmail=null;
    VehicleDatabaseHelper vehicleDatabaseHelper=new VehicleDatabaseHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login_screen);

        setupWindowInsets();
        initializeFirebaseAuth();
        checkLoginStatus();
        initializeUIComponents();
        setupLoginButton();
        setupRegisterButton();
        setupForgotPasswordButton();
    }

    private void setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void initializeFirebaseAuth() {
        mAuth = FirebaseAuth.getInstance();
    }

    private void checkLoginStatus() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isUserLoggedIn = sharedPreferences.getBoolean(IS_USER_LOGGED_IN, false);

        if (isUserLoggedIn) {
            FirebaseUser user = mAuth.getCurrentUser();
            fbEmail=user.getEmail();
            String temUname=vehicleDatabaseHelper.getUserByEmail(fbEmail);
            vehicleDatabaseHelper.addUser(temUname,fbEmail,"temp");
            navigateTo(Dashboard.class);
        }
    }

    private void initializeUIComponents() {
        inputEmail = findViewById(R.id.login_email);
        inputPassword = findViewById(R.id.login_pass);
        inputUserName = findViewById(R.id.userName);
    }

    private void setupLoginButton() {
        Button btnLogin = findViewById(R.id.login_button);
        btnLogin.setOnClickListener(v -> validateAndLogin());
    }

    private void setupRegisterButton() {
        TextView tvRegister = findViewById(R.id.dont_have_acc);
        tvRegister.setOnClickListener(v -> navigateTo(SignupScreen.class));
    }

    private void setupForgotPasswordButton() {
        TextView tvForgotPassword = findViewById(R.id.login_text2);
        tvForgotPassword.setOnClickListener(v -> showForgotPasswordToast());
    }

    private void validateAndLogin() {
        String email = inputEmail.getText().toString().trim();
        String password = inputPassword.getText().toString().trim();
        String userName = inputUserName.getText().toString().trim();

        if(userName.isEmpty()){
            inputUserName.setError("Enter User Name");
            inputUserName.requestFocus();
            return;
        }

        if (email.isEmpty()) {
            inputEmail.setError("Enter Email Address");
            inputEmail.requestFocus();
            return;
        }

        if (email.length() < 10) {
            inputEmail.setError("Enter A Valid Email Address");
            inputEmail.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            inputPassword.setError("Enter Password");
            inputPassword.requestFocus();
            return;
        }

        if (password.length() < MIN_PASSWORD_LENGTH) {
            inputPassword.setError("Password should be at least " + MIN_PASSWORD_LENGTH + " characters");
            inputPassword.requestFocus();
            return;
        }
        fbEmail=email;
        vehicleDatabaseHelper.addUser(userName,email,password);
        Toast.makeText(getApplicationContext(), "Welcome, " + userName + "!", Toast.LENGTH_SHORT).show();
        performLogin(email, password);
    }

    private void performLogin(String email, String password) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        saveLoginStatus(true);
                        checkEmailVerification();
                    } else {
                        handleLoginFailure(task.getException());
                    }
                });
    }

    private void saveLoginStatus(boolean isLoggedIn) {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(IS_USER_LOGGED_IN, isLoggedIn);
        editor.apply();
    }

    private void checkEmailVerification() {
        if (mAuth.getCurrentUser() != null && mAuth.getCurrentUser().isEmailVerified()) {
            navigateTo(Dashboard.class);
        } else {
            Toast.makeText(this, "Please verify your email address first", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleLoginFailure(Exception e) {
        if (e instanceof FirebaseAuthInvalidCredentialsException) {
            inputPassword.setError("Invalid Password");
            inputPassword.requestFocus();
        } else if (e instanceof FirebaseAuthInvalidUserException) {
            inputEmail.setError("Email Not Registered");
            inputEmail.requestFocus();
        } else {
            Toast.makeText(this, "Oops! Something went wrong", Toast.LENGTH_SHORT).show();
        }
    }

    private void showForgotPasswordToast() {
        Toast.makeText(this, "Forgot password feature not implemented", Toast.LENGTH_SHORT).show();
    }

    private void navigateTo(Class<?> cls) {
        Intent intent = new Intent(this, cls);
        if (fbEmail!=null){
            intent.putExtra("fbEmail",fbEmail);
        }
        startActivity(intent);
        finish();
    }
}